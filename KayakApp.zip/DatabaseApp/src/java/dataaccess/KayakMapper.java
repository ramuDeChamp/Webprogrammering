package dataaccess;

import domain.Kayak;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class KayakMapper {
    public void addKayak(){}
    public void removeKayak(){}
    public void showKayak(){}
    public List<Kayak> showAllKayaks() throws SQLException{
        List<Kayak> kayaks = new ArrayList();               //List to hold the information
        String sql = "SELECT * FROM kayak";                 //A String we send to the DB to retrive the information
        Connection con = DB.getConnection();                //Create a connection to the DB
        PreparedStatement pstmt = con.prepareStatement(sql);//Send the query to the DB as a prepared Statment
        ResultSet rs = pstmt.executeQuery();                //A new instanse of a result set, that hold the information from the DB
        
        // Add all the imported data to the kayaks-list
        while(rs.next()){ 
            String name = rs.getString("name");
            String description = rs.getString("description");
            String color = rs.getString("color");
            int lenght = rs.getInt("lenght");
            Kayak kayak = new Kayak(name, description, color, lenght);
            kayaks.add(kayak);
        }
        return kayaks;
    }
    public static void main(String[] args) throws SQLException {
        KayakMapper km = new KayakMapper();
        List<Kayak> kayaks = km.showAllKayaks();
        
        for (Kayak kayak : kayaks) {
            System.out.println(kayak.getName() + " : " + kayak.getDescription());
        }
    } 
}

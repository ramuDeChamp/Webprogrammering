
package dataaccess;

import domain.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserMapper {
    public static void createUser(String username, String password) throws SQLException{
        String sql = "insert into usertable (username, password)values(?,?);";
        Connection con = DB.getConnection();
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,username);
        pstmt.setString(2,password);
        pstmt.executeUpdate();
    }
    public boolean existingUser(String username) throws SQLException{
        String sql = "Select username from usertable where username=?";
        Connection con = DB.getConnection();
        PreparedStatement pstmt = con.prepareStatement(sql);
        pstmt.setString(1,username);
        ResultSet rs = pstmt.executeQuery();
        if(rs.next()) {
            String usernameFromDB = rs.getString("username");
            if(usernameFromDB.equals(username)) {
                return true;
            }
        }
        return false;
    }
    public List<User> getAllUsers() throws SQLException{
        List<User> users = new ArrayList();
        String sql = "select id, username from usertable";
        Connection con = DB.getConnection();
        PreparedStatement pstmt = con.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
            int id = rs.getInt("id");
            String username = rs.getString("username");
            User user = new User(id, username);
            users.add(user);
        }
        
        return users;
    }
//    public void deleteUser(){}
//    public void editUser(User user){}
    public boolean authenticateUser(String username, String password) {
        try {
            String sql = "select username, password from usertable where username = ?";
            Connection con = DB.getConnection();
            PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.setString(1,username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String passwordFromDB = rs.getString("password");
                if (passwordFromDB.equals(password)) {
                    return true;
                }
            } else {
                return false;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        } 
        return false;
    }
    public static void main(String[] args) throws SQLException {
        UserMapper um = new UserMapper();
//        boolean isAuthenticated = um.existingUser("dfgdfg");
//        if (isAuthenticated)
//            System.out.println("User exsist");
//        else
//            System.out.println("He isent there!");
    
        createUser("newTestUser","password123");

        List<User> users = um.getAllUsers();
        for (User user : users) {
            System.out.println(user.getUsername());
            
        }
    }
}

package dataaccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    private static final String DRIVER = "com.mysql.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/test1";
    private static final String USER = "root";
    private static final String PASSWORD = "1808889142jegersej";
    private static Connection conn = null;
    
    public static Connection getConnection() {
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL,USER,PASSWORD);
        } catch (ClassNotFoundException | SQLException ex) {
        }
        return conn;
    }

    /*public static void main(String[] args) throws SQLException {
        java.sql.Statement stmt = getConnection().createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM kayak");
        
        while(rs.next()) {   
            int id = rs.getInt("id");
            String name = rs.getString("name");
            String description = rs.getString("description");
            String color = rs.getString("color");
            int lenght= rs.getInt("lenght");
            
            //String username = rs.getString("username");
            //String password = rs.getString("password");
            System.out.println(id+":"+name+":"+description+":"+color+":"+lenght);
        }
    }*/
    
}

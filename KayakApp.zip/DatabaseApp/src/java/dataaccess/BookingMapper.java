package dataaccess;

import domain.Kayak;
import domain.User;
import java.util.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


public class BookingMapper {
    private static void makeBooking(User user, Kayak kayak, Date date) throws SQLException {
        String sql = "INSERT INTO booking(username, kayak, date) VALUES(?,?,?)";
        Connection con = DB.getConnection();                    //Create a connection to the DB
        PreparedStatement pstmt = con.prepareStatement(sql);    //Send the query to the DB as a prepared Statment
        DateFormat df = new SimpleDateFormat("yyyyMMdd");       //Create a formatter to format the date to DB-format
        
        pstmt.setString(1, user.getUsername());                 //Insert the first variable in the sql-string
        pstmt.setString(2, kayak.getName());                    //Insert the second variable in the sql-string
        pstmt.setString(3, df.format(date));                    //Insert the third variable in the sql-string
        
        pstmt.executeUpdate();
    }
    private static boolean isBooked(Date date, Kayak kayak) throws SQLException{
        String sql = "SELECT booking.date, kayak.name FROM booking INNER JOIN kayak ON booking.kayak = kayak.name WHERE booking.date=? AND kayak.name=?";
        Connection con = DB.getConnection();                    //Create a connection to the DB
        PreparedStatement pstmt = con.prepareStatement(sql);    //Send the query to the DB as a prepared Statment
        DateFormat df = new SimpleDateFormat("yyyyMMdd");       //Create a formatter to format the date to DB-format
        
        pstmt.setString(1, df.format(date));                    //Insert the first variable in the sql-string
        pstmt.setString(2, kayak.getName());                    //Insert the second variable in the sql-string
        
        ResultSet rs = pstmt.executeQuery();                    //Exceute the query
        
        if(!rs.next()) {
            return false;           //If nothing is returned from DB = no booking with the specific data
        } else {
            return true;
        }
    }    
    private List<Kayak> getAvailableKayaks(Date date){
        List<Kayak> kayaks = new ArrayList();
        return kayaks;
    }

    public static void main(String[] args) throws SQLException {
        Date date = new Date();
        Kayak kayak = new Kayak("Chasm Chaser", "", "", 123);
        User user = new User("rasmusThorsted");
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        
        System.out.println(df.format(date));
        System.out.println(kayak.getName());
        System.out.println(user.getUsername());
       
        makeBooking(user, kayak, date);
        
        //boolean tjek = isBooked(date, kayak);
        //System.out.println(tjek);
        
    }
}

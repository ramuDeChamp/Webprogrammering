package presentation;

import dataaccess.KayakMapper;
import dataaccess.UserMapper;
import static dataaccess.UserMapper.createUser;
import domain.Kayak;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Login", urlPatterns = {"/Login"})

public class Login extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        HttpSession session = request.getSession();   //Instantiate a new object of the browser-session
        UserMapper um = new UserMapper();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        //Checks where we come from, and response accordingly
        String origin = request.getParameter("origin");
        switch(origin){
            
            // If the source is the new user-button, the createUser-method is called
            case "New user":
                try {
                    if (username == null || password == null || username == "" || password == "") {
                        session.setAttribute("error","<p>You need to fill out the username and password</p>");
                    } else {
                        boolean userExsist = um.existingUser(username);
                        if (userExsist) {
                            session.setAttribute("error","<p>The username is already in use. Try another one</p>");
                        } else {
                            createUser(username, password);
                            session.setAttribute("error","<p>Your user has been created</p>");
                        }
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }
                response.sendRedirect("login.jsp");
                break;
            
            //If the source is the login-button the user is authenticated and redirected to the showallkayaks-page. If not: redirected to the login-page again:
            case "Login":
                boolean isAuthenticated = um.authenticateUser(username, password);
                if (isAuthenticated) {            
                    try {
                        session.setAttribute("username", request.getParameter("username")); //Attach username on the session

                        KayakMapper km = new KayakMapper();
                        List<Kayak> kayaks = km.showAllKayaks();
                        session.setAttribute("kayaklist", kayaks);
                        response.sendRedirect("showallkayaks.jsp");

                    } catch (SQLException ex) {
                        Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    session.invalidate();
                    response.sendRedirect("login.jsp");
                }  
                break;
            
            // If the source is the log out button, the browser-session is cleared and the user is redirected to the login-page
            case "Log out":
                session.invalidate();
                response.sendRedirect("login.jsp");
                break;
            
                
            case "Book":
                
                break;
            // If the source is unknown, the browser-session is cleared and the user is redirected to the login-page    
            default:
                session.invalidate();
                response.sendRedirect("login.jsp");
                break;
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
